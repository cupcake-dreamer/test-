package com.donutsmp.core;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemStack;

public final class MenuListener implements Listener {
    private final DonutSMP plugin;
    public MenuListener(DonutSMP plugin){this.plugin=plugin;}

    @EventHandler public void onClick(InventoryClickEvent e){
        if(!(e.getWhoClicked() instanceof Player p))return;
        String title=e.getView().getTitle();
        boolean settings=title.equals(DonutSMP.color("&8Settings"));
        boolean pay=title.equals(DonutSMP.color("&8Pay a Player"));
        boolean request=title.equals(Menus.REQUEST_TITLE);
        boolean confirm=title.equals(DonutSMP.color("&8Confirm Payment"));
        if(!settings&&!pay&&!request&&!confirm)return;
        e.setCancelled(true);
        if(e.getRawSlot()<0||e.getRawSlot()>=e.getView().getTopInventory().getSize())return;
        ItemStack clicked=e.getCurrentItem();if(clicked==null)return;
        int slot=e.getRawSlot();
        if(settings){
            var id=p.getUniqueId();
            switch(slot){
                case 10->plugin.allowTpa().put(id,!plugin.pref(plugin.allowTpa(),id));
                case 12->plugin.allowTpahere().put(id,!plugin.pref(plugin.allowTpahere(),id));
                case 14->plugin.allowPay().put(id,!plugin.pref(plugin.allowPay(),id));
                case 16->plugin.sounds().put(id,!plugin.pref(plugin.sounds(),id));
                case 22->plugin.messages().put(id,!plugin.pref(plugin.messages(),id));
                default->{return;}
            }
            p.closeInventory();
            Menus.openSettings(plugin,p);
            return;
        }
        if(request){
            p.closeInventory();
            if(slot==11)Menus.acceptTeleport(plugin,p);
            else if(slot==15)Menus.denyTeleport(plugin,p);
            return;
        }
        if(pay){
            if(clicked.getType()==Material.BARRIER){p.closeInventory();return;}
            if(clicked.getType()==Material.PLAYER_HEAD&&clicked.hasItemMeta()){
                String name=org.bukkit.ChatColor.stripColor(clicked.getItemMeta().getDisplayName());
                Player target=Bukkit.getPlayerExact(name);
                if(target!=null){p.closeInventory();Menus.askPaymentAmount(plugin,p,target);}
            }
            return;
        }
        if(confirm){
            DonutSMP.Payment payment=plugin.payments().remove(p.getUniqueId());
            p.closeInventory();
            if(payment==null||payment.amount()<0){p.sendMessage(DonutSMP.color("&cPayment expired."));return;}
            if(slot!=11){p.sendMessage(DonutSMP.color("&cPayment cancelled."));return;}
            Player target=Bukkit.getPlayer(payment.target());
            if(target==null||!plugin.pref(plugin.allowPay(),target.getUniqueId())){p.sendMessage(DonutSMP.color("&cThat player cannot receive payments right now."));return;}
            if(!plugin.economy().has(p,payment.amount())){p.sendMessage(DonutSMP.color("&cYou don't have enough money."));return;}
            plugin.economy().withdrawPlayer(p,payment.amount());plugin.economy().depositPlayer(target,payment.amount());
            p.sendMessage(DonutSMP.color("&aYou paid &6"+plugin.economy().format(payment.amount())+" &ato "+target.getName()+"."));
            target.sendMessage(DonutSMP.color("&aYou received &6"+plugin.economy().format(payment.amount())+" &afrom "+p.getName()+"."));
        }
    }
    @EventHandler public void onDrag(InventoryDragEvent e){
        String title=e.getView().getTitle();
        if(title.equals(DonutSMP.color("&8Settings"))||title.equals(DonutSMP.color("&8Pay a Player"))||title.equals(Menus.REQUEST_TITLE)||title.equals(DonutSMP.color("&8Confirm Payment")))e.setCancelled(true);
    }
    @EventHandler public void onChat(AsyncPlayerChatEvent e){
        Player p=e.getPlayer();DonutSMP.Payment pending=plugin.payments().get(p.getUniqueId());
        if(pending==null||pending.amount()!=-1)return;
        e.setCancelled(true);String text=e.getMessage().trim();
        Bukkit.getScheduler().runTask(plugin,()->{
            if(text.equalsIgnoreCase("cancel")){plugin.payments().remove(p.getUniqueId());p.sendMessage(DonutSMP.color("&cPayment cancelled."));return;}
            double amount;try{amount=Double.parseDouble(text);}catch(NumberFormatException ex){p.sendMessage(DonutSMP.color("&cEnter a valid amount, or type cancel."));return;}
            Player target=Bukkit.getPlayer(pending.target());
            if(target==null){plugin.payments().remove(p.getUniqueId());p.sendMessage(DonutSMP.color("&cThat player went offline."));return;}
            Menus.openPaymentConfirm(plugin,p,target,amount);
        });
    }
}
