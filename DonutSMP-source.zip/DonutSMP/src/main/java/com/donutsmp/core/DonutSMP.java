package com.donutsmp.core;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class DonutSMP extends JavaPlugin {
    public enum RequestType { TO_PLAYER, HERE }
    public record TeleportRequest(UUID requester, RequestType type) {}
    public record Payment(UUID target, double amount) {}

    private Economy economy;
    private final Map<UUID, TeleportRequest> requests = new HashMap<>();
    private final Map<UUID, Payment> payments = new HashMap<>();
    private final Map<UUID, Boolean> allowTpa = new HashMap<>();
    private final Map<UUID, Boolean> allowTpahere = new HashMap<>();
    private final Map<UUID, Boolean> allowPay = new HashMap<>();
    private final Map<UUID, Boolean> sounds = new HashMap<>();
    private final Map<UUID, Boolean> messages = new HashMap<>();

    @Override public void onEnable() {
        saveDefaultConfig();
        loadPreferences();
        RegisteredServiceProvider<Economy> registration = getServer().getServicesManager().getRegistration(Economy.class);
        if (registration == null) {
            getLogger().severe("No Vault economy provider found. Install EssentialsX Economy and Vault.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        economy = registration.getProvider();
        getServer().getPluginManager().registerEvents(new MenuListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getLogger().info("DonutSMP enabled. EssentialsX remains responsible for all home commands.");
    }

    @Override public void onDisable() { savePreferences(); }
    public Economy economy() { return economy; }
    public Map<UUID, TeleportRequest> requests() { return requests; }
    public Map<UUID, Payment> payments() { return payments; }
    public Map<UUID, Boolean> allowTpa() { return allowTpa; }
    public Map<UUID, Boolean> allowTpahere() { return allowTpahere; }
    public Map<UUID, Boolean> allowPay() { return allowPay; }
    public Map<UUID, Boolean> sounds() { return sounds; }
    public Map<UUID, Boolean> messages() { return messages; }

    public boolean pref(Map<UUID, Boolean> map, UUID id) { return map.getOrDefault(id, true); }
    public String msg(String key) {
        return color(getConfig().getString("messages.prefix", "&8[&6DonutSMP&8] ")
                + getConfig().getString("messages." + key, ""));
    }
    public static String color(String text) { return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text); }

    private void loadPreferences() {
        var data = getConfigData();
        for (String raw : data.getKeys(false)) {
            try {
                UUID id = UUID.fromString(raw);
                allowTpa.put(id, data.getBoolean(raw + ".allow-tpa", true));
                allowTpahere.put(id, data.getBoolean(raw + ".allow-tpahere", true));
                allowPay.put(id, data.getBoolean(raw + ".allow-pay", true));
                sounds.put(id, data.getBoolean(raw + ".sounds", true));
                messages.put(id, data.getBoolean(raw + ".messages", true));
            } catch (IllegalArgumentException ignored) {}
        }
    }
    private org.bukkit.configuration.file.YamlConfiguration getConfigData() {
        java.io.File file = new java.io.File(getDataFolder(), "players.yml");
        if (!file.exists()) try { getDataFolder().mkdirs(); file.createNewFile(); } catch (java.io.IOException ex) { getLogger().warning("Could not create players.yml"); }
        return org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(file);
    }
    private void savePreferences() {
        var data = getConfigData();
        java.util.Set<UUID> ids = new java.util.HashSet<>();
        ids.addAll(allowTpa.keySet()); ids.addAll(allowTpahere.keySet()); ids.addAll(allowPay.keySet());
        ids.addAll(sounds.keySet()); ids.addAll(messages.keySet());
        for (UUID id : ids) {
            String path = id.toString();
            data.set(path + ".allow-tpa", pref(allowTpa, id));
            data.set(path + ".allow-tpahere", pref(allowTpahere, id));
            data.set(path + ".allow-pay", pref(allowPay, id));
            data.set(path + ".sounds", pref(sounds, id));
            data.set(path + ".messages", pref(messages, id));
        }
        try { data.save(new java.io.File(getDataFolder(), "players.yml")); }
        catch (java.io.IOException ex) { getLogger().severe("Could not save player settings: " + ex.getMessage()); }
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase();
        if (!(sender instanceof Player player)) { sender.sendMessage("This command can only be used in-game."); return true; }
        UUID id = player.getUniqueId();
        switch (name) {
            case "settings" -> { if (!player.hasPermission("donutsmp.settings")) return noPermission(player); Menus.openSettings(this, player); return true; }
            case "tptoggle" -> { allowTpa.put(id, !pref(allowTpa, id)); player.sendMessage(color("&aIncoming /tpa: " + (pref(allowTpa,id) ? "&aEnabled" : "&cDisabled"))); savePreferences(); return true; }
            case "tpa", "tpahere" -> {
                if (!player.hasPermission("donutsmp.tpa")) return noPermission(player);
                if (args.length != 1) { player.sendMessage(color("&cUsage: /" + name + " <player>")); return true; }
                Player target = Bukkit.getPlayerExact(args[0]);
                if (target == null || target.equals(player)) { player.sendMessage(color("&cThat player is offline or invalid.")); return true; }
                boolean here = name.equals("tpahere");
                if (!(here ? pref(allowTpahere, target.getUniqueId()) : pref(allowTpa, target.getUniqueId()))) {
                    player.sendMessage(color("&cThat player is not accepting this type of teleport request.")); return true;
                }
                requests.put(target.getUniqueId(), new TeleportRequest(id, here ? RequestType.HERE : RequestType.TO_PLAYER));
                player.sendMessage(color("&aTeleport request sent to &f" + target.getName() + "&a."));
                if (pref(messages, target.getUniqueId())) {
                    target.sendMessage(color("&6" + player.getName() + (here ? " wants you to teleport to them." : " wants to teleport to you.")));
                    target.sendMessage(color("&a[ACCEPT] &7Use &f/tpaccept &7or click the accept button in the request menu."));
                    target.sendMessage(color("&c[DENY] &7Use &f/tpdeny&7."));
                }
                Menus.openTeleportRequest(this, target, player, here);
                long expiry = getConfig().getLong("teleport-request-expiry-seconds", 60);
                Bukkit.getScheduler().runTaskLater(this, () -> {
                    TeleportRequest current = requests.get(target.getUniqueId());
                    if (current != null && current.requester().equals(id)) {
                        requests.remove(target.getUniqueId());
                        if (player.isOnline()) player.sendMessage(color("&cYour teleport request expired."));
                        if (target.isOnline() && target.getOpenInventory().getTitle().equals(Menus.REQUEST_TITLE)) target.closeInventory();
                    }
                }, expiry * 20L);
                return true;
            }
            case "tpaccept" -> { Menus.acceptTeleport(this, player); return true; }
            case "tpdeny" -> { Menus.denyTeleport(this, player); return true; }
            case "pay" -> {
                if (!player.hasPermission("donutsmp.pay")) return noPermission(player);
                if (args.length == 0) { Menus.openPay(this, player); return true; }
                if (args.length == 1) {
                    Player target = Bukkit.getPlayerExact(args[0]);
                    if (target == null || target.equals(player)) { player.sendMessage(color("&cPlayer not found.")); return true; }
                    if (!pref(allowPay, target.getUniqueId())) { player.sendMessage(color("&cThat player is not accepting payments.")); return true; }
                    Menus.askPaymentAmount(this, player, target);
                    return true;
                }
                if (args.length == 2) {
                    Player target = Bukkit.getPlayerExact(args[0]);
                    if (target == null || target.equals(player)) { player.sendMessage(color("&cPlayer not found.")); return true; }
                    double amount;
                    try { amount = Double.parseDouble(args[1]); } catch (NumberFormatException ex) { player.sendMessage(color("&cEnter a valid amount.")); return true; }
                    Menus.openPaymentConfirm(this, player, target, amount);
                    return true;
                }
                player.sendMessage(color("&cUsage: /pay [player] [amount]")); return true;
            }
        }
        return false;
    }
    private boolean noPermission(Player p) { p.sendMessage(color("&cYou don't have permission to do that.")); return true; }
}
