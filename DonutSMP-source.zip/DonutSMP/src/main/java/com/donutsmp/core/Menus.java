package com.donutsmp.core;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.List;

public final class Menus {
    private Menus() {}
    public static final String REQUEST_TITLE = DonutSMP.color("&8Teleport Request");
    static ItemStack item(Material type, String name, String... lore) {
        ItemStack stack = new ItemStack(type);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(DonutSMP.color(name));
        meta.setLore(java.util.Arrays.stream(lore).map(DonutSMP::color).toList());
        stack.setItemMeta(meta);
        return stack;
    }
    static void fill(Inventory inv) {
        ItemStack pane = item(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i=0;i<inv.getSize();i++) if (inv.getItem(i)==null) inv.setItem(i,pane);
    }
    public static void openSettings(DonutSMP plugin, Player p) {
        Inventory inv=Bukkit.createInventory(null,27,DonutSMP.color("&8Settings"));
        inv.setItem(10,item(Material.ENDER_PEARL,"&6Allow /tpa","&7Allow players to teleport to you","&fStatus: "+status(plugin.pref(plugin.allowTpa(),p.getUniqueId()))));
        inv.setItem(12,item(Material.CHORUS_FRUIT,"&6Allow /tpahere","&7Allow players to request you teleport to them","&fStatus: "+status(plugin.pref(plugin.allowTpahere(),p.getUniqueId()))));
        inv.setItem(14,item(Material.EMERALD,"&6Allow payments","&7Allow players to send you money","&fStatus: "+status(plugin.pref(plugin.allowPay(),p.getUniqueId()))));
        inv.setItem(16,item(Material.BELL,"&6Notification sounds","&7Toggle menu sounds","&fStatus: "+status(plugin.pref(plugin.sounds(),p.getUniqueId()))));
        inv.setItem(22,item(Material.PAPER,"&6Request messages","&7Toggle incoming request messages","&fStatus: "+status(plugin.pref(plugin.messages(),p.getUniqueId()))));
        fill(inv); p.openInventory(inv);
    }
    private static String status(boolean b){return b?"&aEnabled":"&cDisabled";}
    public static void openPay(DonutSMP plugin, Player p) {
        Inventory inv=Bukkit.createInventory(null,54,DonutSMP.color("&8Pay a Player"));
        int slot=0;
        for(Player target:Bukkit.getOnlinePlayers()){
            if(target.equals(p)||slot>=45||!plugin.pref(plugin.allowPay(),target.getUniqueId()))continue;
            ItemStack head=new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta=(SkullMeta)head.getItemMeta(); meta.setOwningPlayer(target);
            meta.setDisplayName(DonutSMP.color("&6"+target.getName()));
            meta.setLore(List.of(DonutSMP.color("&7Click to choose an amount"))); head.setItemMeta(meta);
            inv.setItem(slot++,head);
        }
        inv.setItem(49,item(Material.BARRIER,"&cClose")); fill(inv); p.openInventory(inv);
    }
    public static void askPaymentAmount(DonutSMP plugin,Player sender,Player target){
        plugin.payments().put(sender.getUniqueId(),new DonutSMP.Payment(target.getUniqueId(),-1));
        sender.sendMessage(DonutSMP.color("&aEnter the amount to pay &f"+target.getName()+"&a in chat, or type &fcancel&a."));
    }
    public static void openPaymentConfirm(DonutSMP plugin,Player sender,Player target,double amount){
        if(!Double.isFinite(amount)||amount<plugin.getConfig().getDouble("minimum-payment",1)||amount>plugin.getConfig().getDouble("maximum-payment",1.0E9)){
            sender.sendMessage(DonutSMP.color("&cInvalid payment amount."));return;
        }
        if(!plugin.pref(plugin.allowPay(),target.getUniqueId())){sender.sendMessage(DonutSMP.color("&cThat player is not accepting payments."));return;}
        if(!plugin.economy().has(sender,amount)){sender.sendMessage(DonutSMP.color("&cYou don't have enough money."));return;}
        plugin.payments().put(sender.getUniqueId(),new DonutSMP.Payment(target.getUniqueId(),amount));
        Inventory inv=Bukkit.createInventory(null,27,DonutSMP.color("&8Confirm Payment"));
        inv.setItem(11,item(Material.LIME_CONCRETE,"&aConfirm Payment","&7Send &6"+plugin.economy().format(amount)+" &7to","&f"+target.getName()));
        inv.setItem(15,item(Material.RED_CONCRETE,"&cCancel Payment"));
        fill(inv);sender.openInventory(inv);
    }
    public static void openTeleportRequest(DonutSMP plugin,Player target,Player requester,boolean here){
        Inventory inv=Bukkit.createInventory(null,27,REQUEST_TITLE);
        inv.setItem(11,item(Material.LIME_CONCRETE,"&aAccept Request","&7"+(here?"Teleport "+target.getName()+" to "+requester.getName():"Teleport "+requester.getName()+" to you")));
        inv.setItem(15,item(Material.RED_CONCRETE,"&cDeny Request","&7Decline this request"));
        fill(inv);target.openInventory(inv);
    }
    public static void acceptTeleport(DonutSMP plugin,Player target){
        DonutSMP.TeleportRequest request=plugin.requests().remove(target.getUniqueId());
        if(request==null){target.sendMessage(DonutSMP.color("&cYou have no pending teleport requests."));return;}
        Player requester=Bukkit.getPlayer(request.requester());
        if(requester==null){target.sendMessage(DonutSMP.color("&cThat player is no longer online."));return;}
        int delay=plugin.getConfig().getInt("teleport-delay-seconds",3);
        target.sendMessage(DonutSMP.color("&aTeleport request accepted."));
        requester.sendMessage(DonutSMP.color("&aYour teleport request was accepted. Teleporting in "+delay+" seconds."));
        Bukkit.getScheduler().runTaskLater(plugin,()->{
            if(!target.isOnline()||!requester.isOnline())return;
            if(request.type()==DonutSMP.RequestType.HERE) target.teleportAsync(requester.getLocation());
            else requester.teleportAsync(target.getLocation());
        },delay*20L);
    }
    public static void denyTeleport(DonutSMP plugin,Player target){
        DonutSMP.TeleportRequest request=plugin.requests().remove(target.getUniqueId());
        if(request==null){target.sendMessage(DonutSMP.color("&cYou have no pending teleport requests."));return;}
        Player requester=Bukkit.getPlayer(request.requester());
        target.sendMessage(DonutSMP.color("&cTeleport request denied."));
        if(requester!=null)requester.sendMessage(DonutSMP.color("&cYour teleport request was denied."));
    }
}
