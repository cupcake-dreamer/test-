package com.donutsmp.core;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
public final class PlayerListener implements Listener {
    private final DonutSMP plugin;
    public PlayerListener(DonutSMP plugin){this.plugin=plugin;}
    @EventHandler public void onQuit(PlayerQuitEvent e){
        plugin.requests().remove(e.getPlayer().getUniqueId());
        plugin.payments().remove(e.getPlayer().getUniqueId());
    }
}
